let a=Number(prompt("enter the value of a"))
let b=Number(prompt("enter the value of b"))
function demo (a,b,task)
{
  let c=task(a,b)
  return c
}
let res=demo(a,b,function(a,b)
 {
  return a+b;
 })
 console.log(res);

//subtraction
 let d=Number(prompt("enter the value of c"))
let e=Number(prompt("enter the value of d"))
function demo1 (d,e,task1)
{
  let f=task1(d,e)
  return f
}
let res1=demo1(d,e,function(d,e)
 {
  return d-e;
 })
 console.log(res1);

 //multiplication
 let g=Number(prompt("enter the value of g"))
let h=Number(prompt("enter the value of h"))
function demo2(g,h,task)
{
  let i=task(g,h)
  return i
}
let res2=demo2(g,h,function(g,h)
 {
  return g*h;
 })
 console.log(res2);

 //divison
 let j=Number(prompt("enter the value of j"))
let k=Number(prompt("enter the value of k"))
function demo3 (j,k,task)
{
  let l=task(j,k)
  return l
}
let res3=demo3(j,k,function(j,k)
 {
  return j/k;
 })
 console.log(res3);

 //modulus
 let m=Number(prompt("enter the value of j"))
 let n=Number(prompt("enter the value of k"))
 function demo4(j,k,task)
 {
   let o=task(m,n)
   return o
 }
 let res4=demo4(m,n,function(m,n)
  {
   return m%n;
  })
  console.log(res4);

  //largest of three number
  let x=Number(prompt("enter the value of x"))
  let y=Number(prompt("enter the value of y"))
  let z=Number(prompt("enter the value of z"))
  if(x>y && x>z)
  {
    document.write("x is largest"+x)
  }
  else if(z>x && z>y)
  {
    document.write("z is largest"+z)
  }
    else
    {
     document.write("y is largest"+y)
    }

  
