// function demo2(a)
// {
//   let b=a()
//   return b
// }
// console.log(demo2(function()
// {
//     // console.log("i am document from call back fun1");//it will display on the console
//     document.write("i am document from callback fun1")//it will display on the page
// }
// ));
// console.log(demo2(function()
// {
//     window.alert("i am alert from callback fun2")
// }
// ));


//printing arguments without passing any parameter
// function demo()
// {
//   console.log(arguments.length);
//   console.log(arguments[0]);
//   console.log(arguments[1]);
//   console.log(arguments[2]);

// }
// console.log( demo(10,20,30));

// function operation(a,b,task)
// {
//   let c=task(a,b)
//   return c
// }
// let res=operation(10,20,function(a,b)
// {
//   return a+b;
// })
// console.log(res);
// let res1=operation(10,20,function(a,b)
// {
//   return a-b;
// })
// console.log(res1);
// let res2=operation(10,20,function(a,b)
// {
//   return a*b;
// })
// console.log(res2);

//example 3

// function main(cb1)
// {
//   let cb=cb1()//call back function
//   return cb
// }

// let a=main(function() //higher order function
// {
//   let h1=document.getElementsByTagName("h1")
//   console.log(h1[0]);
//   h1[0].style.backgroundColor="red"
// })
// console.log(a);
// let b=main (function()
// {
//   let p=document.getElementsByTagName("p")
//   console.log(p[0]);
//   p[0].style.backgroundColor="yellow"
// })
// console.log(b);

//4th example this keyword
// var a=10;
// function demo()
// {
//   let a=20;
//   console.log(a);
//   console.log(this.a);
// }
// console.log(demo());

// 5th examples
let operation=function(task)
{
  let a=task()
  return a
}
let res=operation(function(){
  return 'i am call-back fun1'
})
console.log(res);

let res1=operation(function(){
  return 'i am call-back fun2'
})
console.log(res1);