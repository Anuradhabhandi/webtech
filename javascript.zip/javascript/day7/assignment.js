let a=Number(prompt("enter value of a"))
let b=Number(prompt("enter value of b"))
let c=Number(prompt("enter the value of c"))
function demo(a,b,c)
{

   let sum=a+b+c
    return sum
   
}
let d=demo(a,b,c)
console.log(d)

function demo1(a,b,c)
 {    
    let sub=a-b-c
   return sub
}
let e=demo1(a,b,c)
console.log(e);

function demo2(a,b,c)
{
    let multi=a*b*c
    return multi
}
let f=demo2(a,b,c)
console.log(f);

function demo3(a,b,c)
{
    let div=a/b
    return div
}
let g=demo3(a,b,c)
console.log(g);

function demo4(a,b,c)
{
    let mod=a%b
    return mod
}
let h=demo4(a,b,c)
console.log(h);
