// (
//     function(){
//         (function()
//         {
//             console.log('hello-world');
//         })()
//         let demo1=function()
//         {
//             console.log("how are you");
//         }
//         demo1()
//         function demo()
//         {
//             console.log("hello");
//         }
//         demo()
//     }
// )()

//function expression using IIEF

// let demo=(function(){
//     console.log('hello-world');
// })()

//function declartion using IIEF
// (function demo1(){
//     console.log("i am function dec-statement");
// })()

//arrow function in IIEF
// (()=>{
//     console.log("i am arrow function");
// })()

//main purpose of using IIEF function to avoid global pollute namespace....vani is gandi bachii

(function()
{
    var user_name="abhi"

    function demo()
    {
        let name=`${user_name}`
        return name
    }
    console.log(demo());

    var age=10;
    function demo1()
    {
        let age1=`${++age}`
        return age1
    }
    console.log(demo1());
})()