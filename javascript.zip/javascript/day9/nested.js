// function parent()
// {
//     let a=20
//     console.log(a);
//     function child()
//     {
//         let b=30
//         console.log(b);
        
//     }
//     return child()//20
// }
// parent()//20 30

//lexical scope
// var age=10
// function sample()
// {
//     console.log(++age);
// }
// sample()


//example 3
// function parent()
// {
//     let a=10;
//     function child()
//     {
//         console.log(a);
//     }
//     return child
// }
// parent ()()
// parent ()()

//example 4
function parent()
{
    function child1()
    {
        console.log(" i am child 1");
        function child1_1()
        {
            console.log(" i am child 1.1");
        }
        return child1_1
    }
    function child2()
    {
        console.log("i am child 2");
        function child2_1()
        {
            console.log("i am child 2.2");
        }
        return child2_1
    }
    return[child1,child2]
}
let result=parent()
console.log(result)
console.log(result[0]);
console.log(result[0]()());
console.log(result[1]);
console.log(result[1]()());