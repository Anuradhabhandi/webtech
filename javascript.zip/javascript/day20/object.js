//iteral way

let obj={
    name:"anu",
    Id:1,
    demo:function()
    {
        console.log('hello world');
    }
}
console.log(obj);
console.log(obj.demo);
console.log(obj.demo());

//function constructor
//we cannot use arrow function to create function constructor why because arrow function will not take new keyowrd
function obj1(name,id)
{
  this.name=name;
  this.id=id;
}
let obj2=new obj1('abhi',1)
console.log(obj2);

//object methods

let obj3={
    name:'vanita',
    id:1
}
console.log(obj3);

console.log(obj3.name);

//change the existing value

obj.id=2
console.log(obj);

//to add new key and value pair

obj.designation="developer"
console.log(obj);

//to delete key and value pair

delete obj.designation
console.log(obj);

//to print only keys

console.log(Object.keys(obj));

//to print only values
console.log(Object.values(obj));

// convert object into array

console.log(Object.entries(obj));


//to iterate an array
let objj=Object.entries(obj)
console.log(objj);
objj.map((ele)=>{
    console.log(ele[0],ele[1]);
})

//to concat two object

let obj5={
    age:25
}
console.log(Object.assign(obj,obj5));

//seal:-cannot update key and value pair but exisiting value can be updated
Object.seal(obj)

console.log(obj);

obj.designation="tester"

console.log(obj);

obj.age=23
console.log(obj);

//freeze :-cannot update key and value pair and we cannot update existing value also


Object.freeze(obj)

obj.designation="developer"
console.log(obj);

obj.age=100
console.log(obj);

//to create the object
Object.create

//protype is used for oops concept and prototype is the copy of the object
//this protype is assign to proto
//by using this proto we can chnage the value in function,object


//date
let date=new Date;
console.log(date);
console.log(date.getTime());
console.log(date.getFullYear());
console.log(date.getHours());

//math 

//for learning react go with code evaluation
//react.org---offical website

//jquery simplelearn
