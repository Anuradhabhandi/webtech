const clothes=['jacket' ,'t-shirt']; //here we are initialization array 
clothes.length=0;//here we are declaring the lentgth as 0 means we are making array are empty
console.log(clothes[0])// after making array empty we are trying to access the elements so we get output as undefined