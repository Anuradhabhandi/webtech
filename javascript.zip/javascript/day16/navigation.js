// console.log(window);
// console.log(window.navigator);

// console.log(window.navigator.geolocation);

// // console.log(window.navigator.geolocation.getCurrentPosition())

// function get_function()
// {
//     navigator.geolocation.getCurrentPosition((position)=>{
//         console.log(position);
//         let {latitude,longitude}=position.coords
//         console.log(latitude,longitude);
//         let maps="https://www.google.com/maps/place/${latitude},${longitude}"
//         console.log(maps);
        
//     })
    

//     }
//     console.log(get_function());



    //how to convert text in to speech

    //the new keyowrd is used to create a object

    // let demo=document.getElementById("demo")
    // console.log(demo);

    // let convert=document.getElementById("convert")
    // console.log(convert);

    // let speech=new SpeechSynthesisUtterance
    // console.log(speech);

    // convert.onclick=function()
    // {
    //     speech.text=demo.value
    //     speechSynthesis.speak(speech)
    // }


    ///to know online or offline

    if(navigator.onLine)
    {
        document.write("online😍")
    }else
    {
        document.write("offline😒")
    }

    //whenever we click the link should get copy

    let obj={
        title:"webpage",
        author:"jspider",
        url:"http://www.jspider.com"

    }
    console.log(obj);
    let share=document.getElementById("share")
    console.log(share);

    share.onclick=function(){
        console.log(navigator.share(obj));
    }