let grand_parent=document.getElementById("grand_parent")
console.log(grand_parent);

grand_parent.addEventListener("click",(e)=>{
    e.stopImmediatePropagation()
    e.target.style.backgroundColor="green"
    console.log("grand_parent clicked");
},false)

let parent=document.getElementById("parent")
console.log(parent);

parent.addEventListener("click",(e)=>{
    e.stopImmediatePropagation()
    e.target.style.backgroundColor="orange"
    console.log("parent clicked");
},false)

let child=document.getElementById("child")
console.log(child);

child.addEventListener("click",(e)=>{
    e.stopImmediatePropagation()
    e.target.style.backgroundColor="white"
    console.log("child clicked");
},false)