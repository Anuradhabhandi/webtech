let web=document.getElementById("web")
console.log(web);


web.onclick=function(){
    let video=document.getElementById("video")
    console.log(video);
    navigator.mediaDevices.getUserMedia({
        audio:true,
        video:{height:200,width:200}
    })
    .then((stream)=>{
        video.srcObject=stream
        video.play()
    }).catch((err)=>{
        console.log(err);
    })
}