let copy=document.getElementById("copy")
console.log(copy);

copy.addEventListener("click",()=>{
    let demo=document.getElementById("demo").value
    console.log(demo);
    navigator.clipboard.writeText(demo)
    .then(()=>{
        window.alert("code copied")
    })
    .catch(()=>{
        console.log("error occured");
    })
})


