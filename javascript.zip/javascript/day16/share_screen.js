let share_screen=document.getElementById("share_screen")
console.log(share_screen);

share_screen.onclick=function(){
    navigator.mediaDevices.getDisplayMedia()
}

