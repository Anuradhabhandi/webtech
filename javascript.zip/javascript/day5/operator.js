//arithmetic operator

 let a=10;let b=10;
// console.log(a+b);//20
// console.log(a-b);//0
// console.log(a*b);//100
// console.log(a/b);//1
// console.log(a%b);//0
// console.log(a++);//10 post-increment the value is added in next step
// console.log(++a);//11 pre-increment the value is addded at first line only

// console.log(--a);//9//pre decrement 
// console.log(a--);//9 post decrement
// console.log(a--);//8

//assignment operator
console.log(a+=10);//20
console.log(a-=10);//10
console.log(a*=10);//100
console.log(a/=10);//10
console.log(a%=10);//0

//logical operator AND(&&) OR(||) NOT(!)
//AND :- if both the condition are true then only we wil get output as true if anyone operator is false we get output as false
// console.log(true &&true);//true
// console.log(true&&false);//false
// console.log(false && true);//false
// console.log(false&&false);//false

//OR:- if anyone condition is true we get output as true if both the condition are true we get output as true but when both the condition are false we get output as false
console.log(true||true);//true
console.log(true||false);//true
console.log(false||true);//true
console.log(false||false);//false

//NOT:-if the condition is true we get output as false .if condition is false we get output as true like viceversa
console.log(!true);//false
console.log(!false);//true

// realtional/comparsion operator
//equal to(=):-it will check only number not a datatype
console.log(5==5);//true
console.log(5==6);//false
console.log(5=='5');//true

//strictly equal to(===):-it will check both number and datatype
console.log(5===5);//true
console.log(5===6);//false
console.log(5==='5');//false

//not equals to
console.log(5!=5);//false
console.log(5!==6);//true
//<,<=,>,>=
console.log(5>5);//false
console.log(5<5);//false
console.log(5<=5);//true
console.log(5>=5);//true

//conditional operator
//ternary operator
//syntax
//(condition)?true:false

// let age=18;
// console.log((age>=18)?'major':'minor');

//prompt method :-it is used to get data from the user and its present in window
// let age=window.prompt("enter your age")
// console.log((age>=18)?'major':'minor');

//this all condition are false in javascript
console.log((undefined)?true:false);//false
console.log((null)?true:false);//false
console.log((0)?true:false);//false
console.log((NaN)?true:false);//false

