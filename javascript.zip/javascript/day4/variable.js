'use strict'
// a=10;
// console.log(a);
// console.log(window);

//scope

// var a=10;
// console.log(a);//global scope

// let b=20;
// console.log(b);//local scope

// const c=30;
// console.log(c);//local scope

//declaration

// var a;
// console.log(a);

// let b;
// console.log(b);

// const c;
// console.log(c);//const cannot be declared

//declaration and initization

// var a=10
// console.log(a);

// let b=20
// console.log(b);

// const c=30
// console.log(c);

//re-initilization

// var a=10
// a="hello"
// console.log(a);

// let b=20
// b="world"
// console.log(b);

// const c=30
// c="anu"
// console.log(c);//const cannot be re-initilazed

//re-declaration and re-initliaztion

var a=10
console.log(a);//object refering
var a=20
console.log(a);//object derefering

// let b=30
// console.log(b);
// let b=40
// console.log(b);//we cannot re-decalartion and re-initilaize in let 

// const c=50
// console.log(c);
// const c=60
// console.log(c)//we cannot re-decalartion and re-initilaize in const