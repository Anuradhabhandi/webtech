console.log(a);
var a=10

// console.log(b);
// let b=20;

// console.log(c);
// const c=30;

console.log(demo());

function demo(){
    return "hello world"
}

function demo(){
    return "hello world"
}
console.log(demo());