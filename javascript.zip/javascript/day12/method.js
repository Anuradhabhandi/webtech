//getelementbyid
let a=document.getElementById('demo')
console.log(a);
a.style.backgroundColor="red"
a.textContent="hello-world"

let b=document.getElementsByClassName('demo1')
console.log(b);
console.log(b[0]);
b[0].style.backgroundColor="yellow"

// b[0].firstElementChild.style.color="white"
// b[0].lastElementChild.style.color="red"

//to target children 
console.log(b[0].children);
console.log(b[0].children[0]);
b[0].children[0].style.color="red"

console.dir(b);
console.log(b[0].childNodes); //childnode is used to give the plain text
console.log(b[0].childNodes[2].textContent="hello");