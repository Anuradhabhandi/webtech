//implicit arrow function

let demo=()=>console.log("hello world");
console.log(demo());

let demo1=()=>{
    return "hello world"
}
console.log(demo1());


//hof and cbf by using arrow function

let fun=(a)=>{
    let b=a()
    return b
}
console.log(fun(()=>{
    console.log("i am call-back function1");
}));
console.log(fun(()=>{
    console.log("i am call-back function2");
}));
console.log(fun(()=>{
    console.log("i am call-back function3");
}));

let operation=(m,n,task)=>{
    let o=task(m,n)
    return o
}
let res=operation(10,20,(m,n)=>{
    return m+n
})
console.log(res);
let res1=operation(10,20,(m,n)=>{
    return m-n
})
console.log(res1);
