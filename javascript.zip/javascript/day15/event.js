let btn=document.getElementById("btn")
console.log(btn);

function demo()
{
    console.log("hello world");
}

let input=document.getElementById("input")
console.log(input);

input.onkeypress=function(e){
    console.log(`the key pressed is ${e.key}`);
    // console.log(e);
    console.log(`the key code is ${e.keyCode}`);
}


//to generate otp
let otp=document.querySelector("#otp")
console.log(otp);

otp.onclick=function()
{
    setTimeout(()=>{
        let result=Math.floor(Math.random() * 10000)
        console.log(result);
    },5000)
}

//to generate random color
let color=document.querySelector("#color")
console.log(color);

color.onclick=function()
{
    let res=Math.floor(Math.random()*10000).toString(16)
    console.log(res);
    document.body.style.backgroundColor=`#${res}`
}

let col=document.getElementById("col")
console.log(col);

col.onkeydown=function()
{
    let res=Math.floor(Math.random()*10000).toString(16)
    console.log(res);
    document.body.style.backgroundColor=`#${res}`
}

let mouse=document.getElementById("mouse")
console.log(mouse);

mouse.onmouseover=function()
{
    let res=Math.floor(Math.random()*10000).toString(16)
    console.log(res);
    document.body.style.backgroundColor=`#${res}`
}

let a=prompt("enter the color")
console.log(a);

let btn2=document.getElementById("btn2")
console.log(btn2);

btn2.innerHTML+=a

btn2.onmouseover=function()
{
    document.body.style.backgroundColor=`${a}`
    document.body.style.transition="ease all 5s"
    btn2.body.style.backgroundColor=`${a}`
    btn2.style.transition="ease all 5s"

}

