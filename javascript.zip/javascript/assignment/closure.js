let employee={
    name:"ankita",
    id:1,
    salary:10000


}
console.log(employee());
