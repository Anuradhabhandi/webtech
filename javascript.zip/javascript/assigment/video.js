let video =document.getElementById("video")

video.onclick=function() {
    if(video.paused)
    {
        video.play();
        video.style.background="url(play.png) no-repeat"
    }

    else{
        video.pause();
        video.style.background="url(pause.png) no-repeat"
    }
}