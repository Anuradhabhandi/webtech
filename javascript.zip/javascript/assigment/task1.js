let a=document.getElementById("btn1")
console.log(a);

btn1.onclick=function()
{
    document.body.style.backgroundImage="url('https://cdn.pixabay.com/photo/2023/05/11/06/12/flowers-7985587__340.jpg')"
    document.body.style.backgroundRepeat="no-repeat";
    document.body.style.backgroundImage="block";
    
    
}
// btn1.onclick=function()
// {
//     document.style.backgroundImage="none"
// }