//literal way
let arr=[10,20,30]
console.log(arr);

//new keyword
let arr1=new Array(10,20,30)
console.log(arr1);

//array methods
console.log(arr1.length);

//pop
console.log(arr.pop());

//push
console.log(arr.push("hiii"));
console.log(arr);

//unshift
console.log(arr.unshift(5));
console.log(arr);


//shift
console.log(arr.shift());
console.log(arr);

//delete
console.log(delete arr[0]);
console.log(arr);

//sort
let arr2=[10,40,30,20]
console.log(arr2.sort());

let arr3=[100,5,20,60]
console.log(arr3.sort((a,b)=>{
    return a-b;
}));

//slice
let arr4=[10,20,30,40]
console.log(arr4.slice(0,3));

//splice
console.log(arr4.splice(0,2,"hello"));
console.log(arr4);

//joins
console.log(arr4.join('+'));

//conact
console.log(arr4.concat(arr));

//for each
let arr5=[10,20,30,40]
console.log(arr);
arr5.forEach((index,value) => {
    console.log(`${index}==>${value}`);
});

//filter
arr5.filter((values)=>{
    console.log(values>5);
})

//map


let arr6=arr5.map((ele1=>{
    return ele1+10
}))
console.log(arr6);


//reduce

let arr7=arr5.reduce((acc,li)=>{
    return acc+li;
})
console.log(arr7);