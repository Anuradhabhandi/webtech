let  demo=document.getElementById("demo")
console.log(demo);

console.log(demo.firstChild.textContent="Hello")

console.log(demo.firstElementChild.style.backgroundColor="red");

console.log(demo.lastChild.textContent="world");

console.log(demo.lastElementChild.style.backgroundColor="blue");

console.log(demo.children[0].style.backgroundColor="pink");

console.log(demo.childNodes[0].textContent="hii");

console.log(demo.parentNode);

h