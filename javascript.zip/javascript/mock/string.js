let str="hello world"
console.log(str);

//new keyword
let str1=new String("hii")
console.log(str1);

//constructor
let str2=String("world")
console.log(str2);

//string methods
console.log(str2.length);

//charAt
console.log(str1.charAt(0));

//charAtcode
console.log(str1.charCodeAt(2));

//uppercase
console.log(str1.toUpperCase());

//lowercase
console.log(str2.toLowerCase());

//split
let str4="javascript how are you"
console.log(str4);

let str5=str4.split('')
console.log(str5);

let str6=str4.split(' ')
console.log(str6);

let str7=str4.split('%')
console.log(str7);

//to iteeate the string
for(let i=0;i<str.length;i++)
{
    console.log(str[i]);
}

for(let ele in str)
{
    console.log(ele);
}
for(let ele1 of str1)
{
    console.log(ele1);
}

//concatation

let str11="cascsding"
let str12=str.concat(str11)
console.log(str12);

//start with
console.log(str.startsWith('h'));

//ends with
console.log(str.endsWith('d'));

//trim
console.log(str.trim());

//slicel

//repeat
console.log(str.repeat(4));

//slice
let str10=str.slice(0,4)
console.log(str10);

//replace
let str15="byee"
console.log(str15);
console.log(str15.replace("byee","hii"));
