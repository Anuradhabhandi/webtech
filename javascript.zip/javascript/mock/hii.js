document.body.innerHTML="<h1>hello world</h1>"

let span=document.createElement("span")
console.log(span);

span.textContent="helloworld"

let demo=document.getElementById("demo")
console.log(demo);

let b=document.createElement("h1")
console.log(b);
b.textContent="byee"
demo.firstElementChild.append(b);
