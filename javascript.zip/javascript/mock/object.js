let obj={
    name:'anu',
    id:2,
    demo:function()
    {
        console.log("hellow world");
    }
}
console.log(obj);
console.log(obj.demo);
console.log(obj.demo());