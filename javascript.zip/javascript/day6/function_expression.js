let demo=function()
{
    console.log("hello world");
    
}
console.log(demo);
console.log(demo());


//2nd example if we give two function name then we get error beacuse expression get first priority
let demo1=function sum()
{
    console.log("bhopadha anam");
}
console.log(sum);//error message