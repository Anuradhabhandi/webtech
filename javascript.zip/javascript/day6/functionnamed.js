// console.log(demo);
// console.log(demo());
// function demo()
// {
//     console.log("hello world");//beacuse of this console we getting undefined in output to avoid this we will use return keyword
//     return "hello world"//now undefined is removed
//     console.log('world');//after return keyword any statemnts r anything will not excute
// }
// console.log(demo);//if we use justd demo we get entire body as a output 
// console.log(demo());//hello world


//2nd example
// function sum(a,b)
// {
//     let c=a+b;
//     return c
// }
// console.log(sum);
// console.log(sum(10,20));//30

//3rd example

// function multi()
// {
//     let a=Number( prompt("enter the value of a"))
//     let b=Number(prompt("enter the value of b"))
//     let c=a*b;
//     return c
// }
// console.log(multi());//20

//4th exaample
function mul()
{
    let m=Number(prompt('enter m'))
    let n=Number(prompt('enter n'))
    let o=m*n;
    return `the mul of ${m} and ${n}==${o}`;
}
window.alert(mul())//20