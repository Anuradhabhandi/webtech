let str=new String("hello");
console.log(str);

let str1="hii";
console.log(str1);
console.log(str1.length);

console.log(str1.charAt(2))

console.log(str.toUpperCase())

console.log(str1.toLowerCase())

console.log(str1.split(''))

console.log(str.split(' '))

for(let i=0;i<str.length;i++)
{
    console.log(str[i]);
}

for(let ele in str1)
{
    console.log(ele)
}

for(let ele of str)
{
    console.log(ele)
}