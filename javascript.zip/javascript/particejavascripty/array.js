let arr=[10,'hello',true,50];
console.log(arr)

let arr1=[10,20,30,40];
console.log(arr1)
console.log(arr1.length);
console.log(arr1.pop())
console.log(arr1.push(80))
console.log(arr1)

console.log(arr1.shift())

console.log(arr1.unshift(5))
console.log(arr1)
console.log(arr1.sort())
console.log(arr1)

let arr3=[10,20,30,40]
console.log(arr3.slice(0,3))

let arr4=[20,30,40,50]
console.log(arr4.splice(0,2,'hello'))
console.log(arr4)