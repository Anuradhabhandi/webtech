console.dir(document)
// console.log(document.links);
// console.log(document.links[0]);
//  console.log(document.links[1]);
//  console.log(document.links[2]);
//  console.log(document.links[0].innerText="chombus");


//to avoid targetting everytime anchor tag with index value we are going to use iterator for loop
// let d=document.links;
// console.log(d);
// for(let i=0;i<d.length;i++)
// {
//     console.log(d[i]);
//     d[i].className="demo" //it is used to give classname
//     d[i].href="https://www.youtube.com"
//     d[0].href="https://www.google.com"  //if you want to provide differenr links to all anchor tag then we have to use index value

// }

//to give and remove the attribute we have property that is setattribute and removeattribute
// console.log(document.links);
// console.log(document.links[0].setAttribute("href","http://www.youtube.com"));
// console.log(document.links[0].setAttribute("target","blank"));

// console.log(document.links[1].setAttribute("href","https://www.netflix.com"));
// console.log(document.links[1].setAttribute("target","blank"));
// document.links[0].removeAttribute("target") //it is used to remove the attribute from the anchor tag

// console.log(document.links[2].setAttribute("href","https://flipkart.com"));


//images 
let image=document.images
console.log(image);
for(let i=0;i<image.length;i++)
{
    console.log(image[i]);

image[i].style.height="200px"
image[i].style.width="200px"
image[i].style.borderRadius="100%"
}

//forms
// console.log(document.forms);
let form=document.forms
console.log(form);
for(let i=0;i<form.length;i++)
{
    console.log(form[i]);
    form[i].style.backgroundColor="pink"
    form[i].style.width="350px"
    form[i].style.height="250px"
    form[i].style.textAlign="center"
    form[i].style.backgroundImage="url('https://cdn.pixabay.com/photo/2023/05/11/06/12/flowers-7985587__340.jpg')"
    form[i].style.backgroundRepeat="none"
    
    form[i][0].style.backgroundColor="red"
    form[i][0].style.height="30px"
    form[i][1].style.backgroundColor="green"
    form[i][1].style.height="30px"
    form[i][2].style.height="30px"
    form[i][2].style.backgroundColor="brown"

}