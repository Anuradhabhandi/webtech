// console.log(window);

// console.log(window.document);

// console.log(document);
// console.dir(document)//directory

// let name=window.prompt("enter your name")
// window.alert("my name is"+name)
// window.confirm()

document.write("<h1 style=color:red> hello who are you</h1>")

document.writeln("hello-world")
document.writeln("hello-world")
document.writeln("hello-world")
document.writeln("hello-world")
document.writeln("hello-world")


console.log(document.URL);
console.log(document.title);
console.log(document);
document.title="flipkart" //it will change the title of the webpage 

console.log(document.head);
console.log(document.body);
console.log(document.location);
console.log(document);

console.log(document.body.firstElementChild.textContent);