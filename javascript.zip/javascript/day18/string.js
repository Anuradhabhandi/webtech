
//literal --way----
let str="hello-world"
console.log(str);

//new keyword

let str1=new String("hello-world")
console.log(str1);

//string using constructor

let str2=String("hii")
console.log(str2);

//---------string methods-------
//length method
console.log(str.length);

//charat method
console.log(str.charAt(0));

//charcodeat method
console.log(str.charCodeAt(0));

//uppercase method:it will work only for english langauge
//tolocaluppercase:it will work other langauge example geeks,alpha
console.log(str.toUpperCase());

//lowercase method
//tolocallowercase:
console.log(str.toLowerCase());

//conacentation 
let str4= "javascript"
let str5= str.concat (str4)
console.log(str5);

//start with method
console.log(str.startsWith('h'));

//ends with method
console.log(str.endsWith('D'));

//trim method
let str6=" js is easy "
console.log(str6);
console.log(str6.trim());

//reapeat method
console.log(str.repeat(3));

//split methods
let str7="java script"
console.log(str7);
let str8=str7.split('')
console.log(str8);
let str9=str7.split(" ")
console.log(str9);
let str10=str7.split("| ")
console.log(str10);

for(let i=0;i<str7.length;i++)
{
    // console.log(i);
    console.log(str4[i]);
}

//for in
for(let ele in str7)
{
    console.log(ele);
}

//for of
for(let ele1 of str7)
{
    console.log(ele1);
}

//for each
str8.forEach((index,value)=>{
 console.log(`${index} ===> ${value}`);
})

//slice 
console.log(str.slice(0,3));//positive slice
console.log(str.slice(-4,-1));//negative slice

//substring
console.log(str.substring(0,3));
console.log(str.substring(-4,-1)); //if we use negative in substring it will print nothing

//substr
console.log(str.substr(0,3));//it is introduced in ecma -version 4
console.log(str.substr(-4,-1));//if we use negative in substr it will print nothing

//replace
let str20="hiii"
console.log(str20);
console.log(str20.replace('hiii','byee'));