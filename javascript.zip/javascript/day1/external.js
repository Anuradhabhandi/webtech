
//to use script src tag anywhere in htm file use async and defer method
console.log("hello world from extrenal")

// let h1=document.getElementsByTagName("h1")
// console.log(h1);
// h1[0].style.backgroundColor="red"

console.error("i am error message")
console.warn("i am warning") 

//object is a key:value pair
let obj={
    name:"Anuradha",
    fathername:"Anilkumar",
    mothername:"Nirmala",
    qualifiaction:"MCA",
    yearofpassout:2022,
    skills:"Html,Css,Javascript,sql,bootstrap",
    hobbies:"travelling,reading,cooking",
    address:"shahbazar near hanuman temple kalburagi state karnataka",
    strengths:"self-motivated,quick learner",
    mobileno:8904308206,
    email:"anuradhabhandi50@gmail.com"


}

console.table(obj)

// console.group("browser name")
// console.log("chrome")
// console.log("IE")
// console.log("duck duck go")
// console.log("safari")
// console.groupEnd()

// console.log(window)
// console.dir(window)