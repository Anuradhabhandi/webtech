//
// let obj={
//     name:"abhi",
//     id:1
// }
// console.log(obj);

// let obj1=JSON.stringify(obj)
// console.log(obj1);

// let obj2=JSON.parse(obj1)
// console.log(obj2);


let btn=document.getElementById("btn")
console.log(btn);

btn.addEventListener('click',(e)=>{
    e.preventDefault()
    let name=document.getElementById('name').value
    let password=document.getElementById('password').value

    let name1=name
    let password1=password
    let obj={name1,password1}
    console.log(obj);
    let obj1=JSON.stringify(obj)
    console.log(obj1);
})