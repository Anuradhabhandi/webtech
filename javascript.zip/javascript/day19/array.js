//literal way

let arr=[10,'hello',true,undefined]
console.log(arr);

//using new keyword

let arr1=new Array(10,20,30,40)
console.log(arr1);

//array methods
let arr2=[10,20,30]
console.log(arr2.length);

console.log(arr2.indexOf(10));// we have to pass the value in indexof

console.log(arr2.includes(10));//it will check the element is present r not

// console.log(arr2.findIndex());

console.log(arr2.pop());
console.log(arr2);/// it is used to remove the element from last it will remove only one at a time

console.log(arr2.push('hello','hii'));
console.log(arr2);//it will add the many elements at a time

console.log(arr2.unshift("javascript"));
console.log(arr2);//it will add the elememt at a starting

console.log(arr2.shift());
console.log(arr2);//it will reemove the element from the starting

console.log(arr2.reverse());

console.log(arr2.join('&'));//it will add the specail character in between of elements

let str="hello"
console.log(str);

let str1=str.split('').reverse().join()
console.log(str1);// we can reverse the string by using thus when there ask by using in bulit methd

let arr3=[50,40,30,20,10]
console.log(arr3.sort());

let arr4=[1000,500,10,1]
console.log(arr4.sort((a,b)=>{
    return a-b;
})); //ascending to descending

let arr5=[1000,500,10,1]
console.log(arr5.sort((a,b)=>{
    return a+b;
}));//descending to ascending

console.log(arr3.slice(0,3));//it will create the new array and left out with last index

console.log(arr5.splice(0,2,'happy'));
console.log(arr5);

console.log(delete arr3[0]);
console.log(arr3);

console.log(arr3.length);

let arr6=[10,20,30,40,50]
console.log(arr6);

arr6.forEach((index,value)=>{
    console.log(`${index}--->${value}`);

})

let arr7=arr6.filter((ele)=>{
    return ele>10
})
console.log(arr7);

let arr8=arr6.map((ele1=>{
    return ele1+10
}))
console.log(arr8);

let arr9=arr1.reduce((acc,li)=>{
   return acc+li
})
console.log(arr9);

let arr10=arr1.reduce((acc,li)=>{
    return acc+li
 },20)
 console.log(arr10);

 