//number datatype
var a=10;
console.log(a)
console.log(typeof a)// to check which type of datatype its
console.log(typeof .5);
console.log(typeof -10);

// console.log(Number);
// console.log(Number());
//the String and Number are function and these are very important in javascript but when we write this number and string in lowercase then its consider as datatype
// console.log(typeof Number);
// console.log(typeof String);

//string data-type
var str='i am a developer'
console.log(str);
console.log(typeof str);

var str1="i'm a developer"
console.log(str1);
console.log(typeof str1);

var str2=`my hobbies are :
          reading
          cooking
   travelling `
   console.log(str2);

   // using \n
   var str3='hello \n world'
   console.log(str3)

   //interoplation
   var a1=10;
   var b1=20;
   var c=a1+b1
   console.log(c);
   console.log(`the sum of ${a1} and ${b1} ==${c}`);

   //boolean data-type
   console.log(true);
   console.log(typeof true);

   console.log(false)
   console.log(typeof false);

   //undefined
   var a2;
   console.log(a2);
   console.log(typeof a2);

   //null
   var a3=null;
   console.log(a3);
   console.log(typeof a3);//typeof null is alwys a object

   //bigint
   var a4=1n
   console.log(a4);
   console.log(typeof a4);

   //primitive datatypes(values cannot be changed until programmer will not change)
   var demo=10;
   console.log(demo);

   var demo1=demo //object referning
   console.log(demo1);

   var demo="hello world"
   console.log(demo);//object dereferning means we removed the value of 10 and giving the string as hello world

   console.log(demo1);

   var demo1=demo
   console.log(demo1);

   //non primitive datatype(values can be changed easily)

   //object,array,function,maps,sets

   let obj={
       name:'anu',
       id:1 
   }
   console.log(obj);

   let obj1=obj
   console.log(obj1);

   obj1.designation='devloper'
   console.log(obj);//if you give obj1 then also we get same output
