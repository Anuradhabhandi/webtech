//implicity type casting
console.log(5+5);//10

console.log(5+'5')//55(here number is converted as string and concentation will happen)

console.log(5-5);//0

console.log(5-'5');//0(insted of addition all operation get output as zero only and here string is converted into number)

console.log(5-'a');//NaN (here js engine trying to convert number into string)
console.log(typeof NaN);//number
console.log((NaN)?true:false);//nan alwys consider as false in js 

//explicit type casting

console.log(5+'5');//55 (but i dont want output as 55 i want output as 10 then we use number)
console.log(5+Number(5));

console.log(5+ String(5));
console.log(Boolean(0));//false
console.log(Boolean(1));//true(other than zero all number positive neagtive all number consider as true)