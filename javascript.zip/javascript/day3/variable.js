//var is having global scope
var a=10;
console.log(a);
 console.log(window)// this is to understand the that is local/global scope...

//local scope
let b=20;
console.log(b);

const c=30;
console.log(c);

//block scope
{
    let d="block scope"
    console.log(d);
}
console.log("hello");